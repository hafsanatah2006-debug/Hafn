import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Coffee, Menu as MenuIcon, Clock, MapPin, Star, Phone, Instagram, Twitter, Facebook, X, Plus, Minus } from 'lucide-react';

interface MenuItem {
  id: number;
  name: string;
  category: 'hot' | 'cold' | 'food';
  price: number;
  description: string;
  image: string;
  ingredients?: string[];
}

const menuItems: MenuItem[] = [
  {
    id: 1,
    name: "Signature Espresso",
    category: "hot",
    price: 4.5,
    description: "Rich, bold single origin espresso with notes of dark chocolate and hazelnut.",
    image: "/images/espresso.jpg",
    ingredients: ["Single Origin Beans", "No Additives"]
  },
  {
    id: 2,
    name: "Velvet Cappuccino",
    category: "hot",
    price: 5.75,
    description: "Perfectly balanced espresso with silky steamed milk and thick foam art.",
    image: "/images/cappuccino.jpg",
    ingredients: ["Espresso", "Whole Milk", "Cocoa Dust"]
  },
  {
    id: 3,
    name: "Caramel Dream Latte",
    category: "hot",
    price: 6.25,
    description: "Espresso, steamed milk, house-made caramel with a touch of sea salt.",
    image: "/images/iced-latte.jpg",
    ingredients: ["Espresso", "Milk", "Caramel", "Sea Salt"]
  },
  {
    id: 4,
    name: "Iced Mocha Bliss",
    category: "cold",
    price: 5.95,
    description: "Cold brew, chocolate, oat milk, topped with house whipped cream.",
    image: "/images/iced-latte.jpg",
    ingredients: ["Cold Brew", "Chocolate", "Oat Milk"]
  },
  {
    id: 5,
    name: "Butterfly Pea Latte",
    category: "cold",
    price: 6.5,
    description: "Beautiful color changing latte with butterfly pea flower, vanilla & honey.",
    image: "/images/cappuccino.jpg",
    ingredients: ["Espresso", "Butterfly Pea", "Vanilla"]
  },
  {
    id: 6,
    name: "Classic Croissant",
    category: "food",
    price: 4.25,
    description: "Buttery, flaky French croissant baked fresh every morning.",
    image: "/images/croissant.jpg",
    ingredients: ["Flour", "Butter", "Yeast"]
  },
  {
    id: 7,
    name: "Avocado Sourdough Toast",
    category: "food",
    price: 7.95,
    description: "Smashed avocado, chili flakes, poached egg on toasted sourdough.",
    image: "/images/croissant.jpg",
    ingredients: ["Avocado", "Sourdough", "Egg"]
  },
  {
    id: 8,
    name: "Blueberry Muffin",
    category: "food",
    price: 3.95,
    description: "Moist blueberry muffin with a streusel topping and lemon zest.",
    image: "/images/croissant.jpg",
    ingredients: ["Blueberries", "Lemon Zest"]
  }
];

const testimonials = [
  {
    name: "Elena Rodriguez",
    text: "The best coffee in the city! The atmosphere makes me feel like I'm in a European cafe. Their latte art is pure magic.",
    rating: 5,
    image: "https://randomuser.me/api/portraits/women/44.jpg"
  },
  {
    name: "Marcus Chen",
    text: "Caffeine Cove has become my daily ritual. The staff remembers your name and your usual order. Truly feels like home.",
    rating: 5,
    image: "https://randomuser.me/api/portraits/men/32.jpg"
  },
  {
    name: "Sophie Laurent",
    text: "Their pastries are heavenly. I come here every Sunday for their fresh croissants and a flat white. A hidden gem!",
    rating: 5,
    image: "https://randomuser.me/api/portraits/women/65.jpg"
  }
];

function App() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'hot' | 'cold' | 'food'>('all');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  // Memory Game States
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [isGameWon, setIsGameWon] = useState(false);

  const filteredItems = activeCategory === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory);

  const addToCart = (item: MenuItem) => {
    setCartCount(prev => prev + 1);
    // Simple toast effect
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-8 right-8 bg-[#3E2723] text-[#F5EDE4] px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-50';
    toast.innerHTML = `
      <div class="w-2 h-2 bg-[#D4AF37] rounded-full animate-pulse"></div>
      Added ${item.name} to cart
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(20px)';
      setTimeout(() => document.body.removeChild(toast), 400);
    }, 2200);
  };

  const openItemModal = (item: MenuItem) => {
    setSelectedItem(item);
    setQuantity(1);
    setIsOrderModalOpen(true);
  };

  const handleAddFromModal = () => {
    if (selectedItem) {
      setCartCount(prev => prev + quantity);
      setIsOrderModalOpen(false);
      
      const toast = document.createElement('div');
      toast.className = 'fixed bottom-8 right-8 bg-emerald-700 text-white px-8 py-4 rounded-2xl shadow-xl flex items-center gap-3 z-[100]';
      toast.textContent = `Added ${quantity} × ${selectedItem.name}`;
      document.body.appendChild(toast);
      
      setTimeout(() => {
        toast.style.transition = 'all 0.5s ease';
        toast.style.transform = 'translateY(30px)';
        toast.style.opacity = '0';
        setTimeout(() => document.body.removeChild(toast), 600);
      }, 1800);
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Memory Game Functions
  const cardEmojis = ['☕', '🧋', '🥐', '🍪', '🥑', '🌰'];
  
  const initializeGame = () => {
    const gameCards = [...cardEmojis, ...cardEmojis]
      .sort(() => Math.random() - 0.5)
      .map((emoji, index) => ({
        id: index,
        value: emoji,
        flipped: false,
        matched: false
      }));
    setCards(gameCards);
    setFlipped([]);
    setMatched([]);
    setMoves(0);
    setIsGameWon(false);
  };

  const flipCard = (id: number) => {
    if (flipped.length === 2 || flipped.includes(id) || matched.includes(id)) return;

    const newFlipped = [...flipped, id];
    setFlipped(newFlipped);
    setMoves(m => m + 1);

    if (newFlipped.length === 2) {
      const [firstId, secondId] = newFlipped;
      const card1 = cards[firstId];
      const card2 = cards[secondId];

      if (card1 && card2 && card1.value === card2.value) {
        setMatched(prev => [...prev, firstId, secondId]);
        setFlipped([]);
        
        if (matched.length + 2 === cards.length) {
          setTimeout(() => setIsGameWon(true), 600);
        }
      } else {
        setTimeout(() => {
          setFlipped([]);
        }, 850);
      }
    }
  };

  useEffect(() => {
    initializeGame();
  }, []);

  return (
    <div className="bg-[#1C140F] text-[#F5EDE4] overflow-x-hidden">
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#1C140F]/95 backdrop-blur-lg border-b border-[#3E2723]">
        <div className="max-w-7xl mx-auto px-8 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <motion.div 
              whileHover={{ rotate: [0, -15, 15, 0] }}
              transition={{ duration: 0.6 }}
              className="w-11 h-11 bg-[#D4AF37] rounded-2xl flex items-center justify-center shadow-inner"
            >
              <Coffee className="w-6 h-6 text-[#1C140F]" />
            </motion.div>
            <div>
              <div className="font-serif text-3xl tracking-tighter font-medium">CAFFEINE</div>
              <div className="text-[10px] text-[#D4AF37] -mt-1 tracking-[3px]">COVE</div>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-9 text-sm uppercase tracking-widest font-light">
            <button onClick={() => scrollToSection('menu')} className="hover:text-[#D4AF37] transition-colors">MENU</button>
            <button onClick={() => scrollToSection('about')} className="hover:text-[#D4AF37] transition-colors">FOUNDER</button>
            <button onClick={() => scrollToSection('visit')} className="hover:text-[#D4AF37] transition-colors">VISIT</button>
            <button onClick={() => scrollToSection('testimonials')} className="hover:text-[#D4AF37] transition-colors">JOURNAL</button>
            <button onClick={() => scrollToSection('game')} className="hover:text-[#D4AF37] transition-colors">PLAY</button>
          </div>

          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => scrollToSection('menu')}
              className="px-6 py-2.5 border border-[#D4AF37]/30 hover:border-[#D4AF37] rounded-full text-sm flex items-center gap-2 transition-all"
            >
              <MenuIcon className="w-4 h-4" /> MENU
            </motion.button>
            
            <motion.div 
              whileHover={{ scale: 1.1 }}
              className="relative cursor-pointer"
              onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
            >
              <div className="w-11 h-11 bg-[#3E2723] hover:bg-[#D4AF37] hover:text-[#1C140F] rounded-2xl flex items-center justify-center transition-all border border-[#D4AF37]/20">
                <Coffee className="w-5 h-5" />
              </div>
              {cartCount > 0 && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-mono w-5 h-5 flex items-center justify-center rounded-full"
                >
                  {cartCount}
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative h-screen flex items-center justify-center pt-16">
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero.jpg" 
            alt="Caffeine Cove Interior" 
            className="w-full h-full object-cover brightness-[0.65]"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1C140F]/70 via-[#1C140F]/60 to-[#1C140F]"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="inline-flex items-center gap-3 text-[#D4AF37] text-sm tracking-[4px] mb-6 font-light border-b border-[#D4AF37]/40 pb-2">
              EST 2017 • SAN FRANCISCO
            </div>
            
            <h1 className="font-serif text-[92px] md:text-[120px] leading-[0.9] tracking-tighter mb-4">
              CAFFEINE<br />COVE
            </h1>
            
            <p className="max-w-md mx-auto text-xl md:text-2xl text-[#EDE0D4] font-light tracking-wide mb-12">
              A sanctuary for the coffee obsessed.<br />Where every cup is crafted with intention.
            </p>
          </motion.div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              onClick={() => scrollToSection('menu')}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              className="group px-14 py-6 bg-[#D4AF37] hover:bg-white text-[#1C140F] font-medium text-lg rounded-3xl flex items-center justify-center gap-4 transition-all shadow-xl"
            >
              BROWSE THE MENU
              <motion.div
                animate={{ x: [0, 6, 0] }}
                transition={{ repeat: Infinity, duration: 1.6 }}
              >
                →
              </motion.div>
            </motion.button>
            
            <motion.button
              onClick={() => scrollToSection('visit')}
              whileHover={{ scale: 1.03 }}
              className="px-10 py-6 border-2 border-white/60 hover:border-white text-lg rounded-3xl transition-all"
            >
              FIND US
            </motion.button>
          </div>
        </div>

        {/* Scroll indicator */}
        <motion.div 
          animate={{ y: [0, 12, 0] }}
          transition={{ duration: 2.2, repeat: Infinity }}
          className="absolute bottom-12 left-1/2 flex flex-col items-center text-xs tracking-widest text-[#D4AF37]/70"
        >
          SCROLL TO EXPLORE
          <div className="w-px h-12 bg-gradient-to-b from-transparent via-[#D4AF37]/40 to-transparent mt-3"></div>
        </motion.div>

        {/* Decorative steam elements */}
        <div className="absolute bottom-36 right-[15%] hidden xl:block">
          {Array.from({ length: 5 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 bg-white/40 rounded-full"
              style={{ left: 40 + i * 13 }}
              animate={{
                y: [-30, -130],
                opacity: [0.6, 0],
                scale: [0.6, 1.6]
              }}
              transition={{
                duration: 3.2 + i * 0.3,
                repeat: Infinity,
                delay: i * 0.3,
              }}
            />
          ))}
        </div>
      </section>

      {/* MENU SECTION */}
      <section id="menu" className="max-w-7xl mx-auto px-8 py-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="text-[#D4AF37] text-sm tracking-[3px] mb-3">CAREFULLY CURATED</div>
            <h2 className="font-serif text-6xl tracking-tight">Our Menu</h2>
          </div>
          
          <div className="flex gap-2 mt-8 md:mt-0 flex-wrap">
            {(['all', 'hot', 'cold', 'food'] as const).map((cat) => (
              <motion.button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`px-8 py-3 text-sm uppercase tracking-wider rounded-3xl transition-all border ${
                  activeCategory === cat 
                    ? 'bg-[#D4AF37] text-[#1C140F] border-[#D4AF37]' 
                    : 'border-white/20 hover:border-white/50'
                }`}
              >
                {cat === 'all' ? 'ALL' : cat.toUpperCase()}
              </motion.button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="wait">
            {filteredItems.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 60 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 30 }}
                transition={{ delay: index * 0.04 }}
                whileHover={{ y: -12 }}
                className="group bg-[#251C17] rounded-3xl overflow-hidden border border-[#3E2723] hover:border-[#D4AF37]/40 cursor-pointer"
                onClick={() => openItemModal(item)}
              >
                <div className="relative h-72 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1C140F] via-[#1C140F]/60 to-transparent" />
                  
                  <div className="absolute top-6 right-6 bg-black/70 px-4 py-1 text-xs rounded-3xl flex items-center gap-1.5 backdrop-blur">
                    <span className="text-[#D4AF37]">★</span>
                    <span>${item.price}</span>
                  </div>
                  
                  {/* Animated steam overlay */}
                  <div className="absolute top-12 left-8 opacity-60">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <motion.div
                        key={i}
                        className="absolute w-[3px] h-12 bg-gradient-to-t from-transparent via-white to-transparent rounded-full"
                        style={{ left: i * 13 }}
                        animate={{ 
                          y: [-50, -140], 
                          opacity: [0, 0.9, 0],
                          height: [20, 55]
                        }}
                        transition={{ 
                          duration: 2.4, 
                          repeat: Infinity, 
                          delay: i * 0.4 
                        }}
                      />
                    ))}
                  </div>
                </div>
                
                <div className="p-8">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-medium text-2xl tracking-tight">{item.name}</h3>
                  </div>
                  <p className="text-[#C8B9A8] text-[15px] leading-snug line-clamp-3 mb-6">
                    {item.description}
                  </p>
                  
                  <div className="flex items-center justify-between">
                    <button 
                      onClick={(e) => { e.stopPropagation(); addToCart(item); }}
                      className="flex items-center gap-2 text-xs uppercase tracking-widest px-6 py-3.5 bg-white/5 hover:bg-[#D4AF37] hover:text-[#1C140F] rounded-2xl transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" /> ADD TO CART
                    </button>
                    
                    <div className="text-[#D4AF37] text-xs flex items-center gap-1">
                      <Star className="w-3 h-3" /> 4.9
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
        
        <div className="text-center mt-16">
          <button 
            onClick={() => setActiveCategory('all')}
            className="inline-flex items-center gap-2 text-sm border-b border-white/30 pb-1 hover:border-white transition-colors"
          >
            VIEW ENTIRE MENU <span className="text-base">↗</span>
          </button>
        </div>
      </section>

      {/* HAFSA'S STORY */}
      <section id="about" className="bg-[#251C17] py-24">
        <div className="max-w-7xl mx-auto px-8 grid md:grid-cols-12 gap-16 items-center">
          <div className="md:col-span-7">
            <div className="uppercase text-xs tracking-[2px] text-[#D4AF37] mb-4">CHAPTER II • HAFSA'S JOURNEY</div>
            <h2 className="font-serif text-6xl tracking-tighter leading-none mb-10">From Struggle<br />to Success</h2>
            
            <div className="max-w-[520px] space-y-8 text-lg text-[#C8B9A8]">
              <p>
                Hafsa started with nothing but a dream and a love for coffee. After losing her corporate job in 2015, she faced years of financial struggles — sleeping on friends' couches, working three jobs, and facing repeated loan rejections from banks who didn't believe in her vision.
              </p>
              <p>
                Undeterred, she self-taught coffee roasting from YouTube tutorials, traveled alone across three continents with a backpack, built relationships with farmers, and faced industry skepticism as a young woman. After 18 failed pop-ups and countless sleepless nights, she finally opened Caffeine Cove in 2017 with her last savings.
              </p>
              <p>
                Today, the Cove is a thriving sanctuary and a symbol of resilience. "Every cup poured here carries the story of persistence," says Hafsa. Her journey reminds us that the best things in life are worth the struggle.
              </p>
            </div>
            
            <div className="mt-12 flex items-center gap-8 text-sm">
              <div>2015 — THE LOWEST POINT</div>
              <div className="h-3 w-px bg-white/30"></div>
              <div>2017 — THE OPENING</div>
              <div className="h-3 w-px bg-white/30"></div>
              <div>TODAY — A LEGACY</div>
            </div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="md:col-span-5 relative"
          >
            <div className="aspect-[4/3] bg-[#1C140F] rounded-3xl overflow-hidden shadow-2xl border border-[#3E2723] relative">
              <img 
                src="/images/hafsa.jpg" 
                alt="Hafsa - Founder" 
                className="w-full h-full object-cover" 
              />
              <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-[#251C17] to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8">
                <div className="text-[#D4AF37] text-sm font-medium">— Hafsa Ahmed, Founder</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section id="testimonials" className="max-w-7xl mx-auto px-8 py-24">
        <div className="text-center mb-16">
          <div className="mx-auto w-16 h-16 rounded-full border border-[#D4AF37]/30 flex items-center justify-center mb-6">
            <Star className="w-8 h-8 text-[#D4AF37]" />
          </div>
          <h2 className="font-serif text-6xl tracking-tight mb-3">Stories from the Cove</h2>
          <p className="text-[#C8B9A8]">Real voices. Real moments.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-[#251C17] p-10 rounded-3xl border border-[#3E2723] flex flex-col"
            >
              <div className="flex mb-8">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-[#D4AF37]" />
                ))}
              </div>
              
              <div className="italic text-xl leading-tight flex-1 text-[#EDE0D4]">
                “{testimonial.text}”
              </div>
              
              <div className="mt-10 flex items-center gap-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-11 h-11 rounded-2xl object-cover ring-2 ring-[#D4AF37]/20" 
                />
                <div>
                  <div>{testimonial.name}</div>
                  <div className="text-xs text-[#C8B9A8]">Regular since 2019</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* COFFEE MEMORY GAME */}
      <section id="game" className="max-w-7xl mx-auto px-8 py-24 bg-[#251C17]">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-[#1C140F] text-[#D4AF37] text-sm tracking-widest px-6 py-2 rounded-3xl mb-6">
            <Coffee className="w-4 h-4" /> COFFEE CHALLENGE
          </div>
          <h2 className="font-serif text-6xl tracking-tighter">Match the Beans</h2>
          <p className="text-[#C8B9A8] mt-4 max-w-md mx-auto">Test your memory with our coffee inspired cards. Match all pairs in the fewest moves!</p>
        </div>

        <div className="flex justify-center mb-8 gap-8 text-sm">
          <div className="bg-[#1C140F] px-8 py-3 rounded-3xl flex items-center gap-3">
            MOVES: <span className="font-mono text-2xl text-[#D4AF37] tabular-nums">{moves}</span>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={initializeGame}
            className="bg-[#D4AF37] hover:bg-white text-[#1C140F] px-8 py-3 rounded-3xl font-medium transition-colors flex items-center gap-2"
          >
            NEW GAME
          </motion.button>
        </div>

        <div className="max-w-[520px] mx-auto">
          <div className="grid grid-cols-4 gap-3">
            {cards.map((card, index) => {
              const isFlipped = flipped.includes(index) || matched.includes(index);
              const isMatched = matched.includes(index);
              
              return (
                <motion.div
                  key={card.id}
                  whileHover={{ scale: isFlipped ? 1 : 1.08 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => flipCard(index)}
                  className={`aspect-square rounded-2xl cursor-pointer flex items-center justify-center text-6xl border-2 transition-all shadow-inner select-none relative overflow-hidden
                    ${isFlipped 
                      ? 'bg-[#3E2723] border-[#D4AF37]' 
                      : 'bg-[#1C140F] border-[#3E2723] hover:border-[#D4AF37]/60'}`}
                >
                  {!isFlipped && (
                    <div className="text-[#D4AF37]/30 text-4xl">☕</div>
                  )}
                  {isFlipped && (
                    <motion.div
                      initial={{ scale: 0.6, rotate: -12 }}
                      animate={{ scale: 1, rotate: 0 }}
                      className={`text-7xl ${isMatched ? 'text-emerald-400' : 'text-white'}`}
                    >
                      {card.value}
                    </motion.div>
                  )}
                  
                  {isMatched && (
                    <div className="absolute inset-0 bg-emerald-500/10"></div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        <AnimatePresence>
          {isGameWon && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 z-[150] flex items-center justify-center bg-black/90"
            >
              <motion.div 
                initial={{ scale: 0.7, y: 40 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-[#1C140F] rounded-3xl p-12 max-w-xs text-center border border-[#D4AF37]/30"
              >
                <div className="text-6xl mb-6">🎉</div>
                <div className="text-4xl font-light mb-2">Amazing!</div>
                <div className="text-[#C8B9A8]">You matched them all in <span className="text-[#D4AF37] font-mono">{moves}</span> moves</div>
                
                <button 
                  onClick={() => {
                    setIsGameWon(false);
                    initializeGame();
                  }}
                  className="mt-10 w-full py-4 bg-[#D4AF37] text-[#1C140F] rounded-2xl font-medium"
                >
                  PLAY AGAIN
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* VISIT US */}
      <section id="visit" className="bg-[#1C140F] py-20 border-t border-b border-[#3E2723]">
        <div className="max-w-7xl mx-auto px-8 grid md:grid-cols-2 gap-20">
          <div>
            <div className="uppercase tracking-[2px] text-sm text-[#D4AF37]">COME SIT WITH US</div>
            <h2 className="font-serif text-6xl mt-3 mb-8 tracking-tight leading-none">The Cove is open<br />for you</h2>
            
            <div className="space-y-8">
              <div className="flex gap-6">
                <Clock className="w-7 h-7 text-[#D4AF37] mt-1" />
                <div>
                  <div className="font-medium mb-1">HOURS</div>
                  <div className="text-[#C8B9A8] space-y-1 text-[15px]">
                    <div>Mon — Fri: 6:30am – 7pm</div>
                    <div>Saturday: 7am – 8pm</div>
                    <div>Sunday: 7:30am – 6pm</div>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-6">
                <MapPin className="w-7 h-7 text-[#D4AF37] mt-1" />
                <div>
                  <div className="font-medium mb-1">LOCATION</div>
                  <div className="text-[#C8B9A8]">
                    412 Valencia Street<br />
                    San Francisco, CA 94103
                  </div>
                  <a href="#" className="inline-block mt-4 text-xs border border-white/30 hover:bg-white/5 px-5 py-3 rounded-2xl transition">GET DIRECTIONS →</a>
                </div>
              </div>
              
              <div className="flex gap-6">
                <Phone className="w-7 h-7 text-[#D4AF37] mt-1" />
                <div>
                  <div className="font-medium mb-1">CONTACT</div>
                  <a href="tel:4155550198" className="text-[#C8B9A8] hover:text-white">(415) 555-0198</a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative h-[520px] rounded-3xl overflow-hidden border border-[#3E2723]">
            <img 
              src="/images/hero.jpg" 
              alt="Storefront" 
              className="absolute inset-0 w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30"></div>
            
            <div className="absolute bottom-0 left-0 right-0 p-10 text-white">
              <div className="uppercase text-xs mb-2 tracking-widest opacity-70">NOW OPEN</div>
              <div className="text-4xl font-light">Walk-ins welcome</div>
              <div className="mt-8 text-xs opacity-60">Free WiFi • Plenty of outlets • Dog friendly patio</div>
            </div>
            
            <motion.div 
              animate={{ 
                boxShadow: ['0 0 0 0px rgba(212, 175, 55, 0.3)', '0 0 0 25px rgba(212, 175, 55, 0)']
              }}
              transition={{ 
                duration: 3.5, 
                repeat: Infinity 
              }}
              className="absolute top-8 right-8 w-5 h-5 border-2 border-[#D4AF37] rounded-full"
            />
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-black pt-20 pb-12">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-2 md:grid-cols-12 gap-y-16">
          <div className="md:col-span-5">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-9 h-9 bg-[#D4AF37] rounded-2xl flex items-center justify-center">
                <Coffee className="text-[#1C140F] w-5 h-5" />
              </div>
              <div className="font-serif text-4xl tracking-tighter">CAFFEINE COVE</div>
            </div>
            
            <p className="max-w-xs text-[#8C7A68] text-sm">
              Thoughtfully sourced. Lovingly prepared.<br />Always with intention.
            </p>
            
            <div className="flex gap-6 mt-16">
              <a href="#" className="text-[#8C7A68] hover:text-[#D4AF37]"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="text-[#8C7A68] hover:text-[#D4AF37]"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-[#8C7A68] hover:text-[#D4AF37]"><Facebook className="w-5 h-5" /></a>
            </div>
          </div>
          
          <div className="md:col-span-3">
            <div className="uppercase text-xs text-white/40 mb-6">QUICK LINKS</div>
            <div className="flex flex-col gap-y-4 text-sm">
              <a href="#" className="hover:text-white">Gift Cards</a>
              <a href="#" className="hover:text-white">Coffee Club</a>
              <a href="#" className="hover:text-white">Wholesale</a>
              <a href="#" className="hover:text-white">Work With Us</a>
            </div>
          </div>
          
          <div className="md:col-span-4">
            <div className="text-xs uppercase tracking-wider text-white/40 mb-5">NEWSLETTER</div>
            <div className="text-2xl leading-none mb-8">Stay in the know about new arrivals, tastings and our seasonal menus.</div>
            
            <div className="flex">
              <input 
                type="text" 
                placeholder="YOUR EMAIL" 
                className="bg-transparent border border-white/30 focus:border-white px-6 py-4 text-sm w-full placeholder:text-white/30 focus:outline-none" 
              />
              <button className="bg-white text-black px-9 text-sm tracking-widest">JOIN</button>
            </div>
            
            <div className="text-[10px] mt-4 text-white/30">We respect your inbox as much as we respect our beans.</div>
          </div>
        </div>
        
        <div className="text-center text-[10px] text-white/30 mt-24">
          © {new Date().getFullYear()} CAFFEINE COVE. ALL RIGHTS RESERVED. MADE WITH COFFEE. CREATED BY HAFSA.
        </div>
      </footer>

      {/* ITEM DETAIL MODAL */}
      <AnimatePresence>
        {isOrderModalOpen && selectedItem && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.88 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", bounce: 0.02, duration: 0.4 }}
              className="bg-[#251C17] max-w-md w-full rounded-3xl overflow-hidden"
            >
              <div className="relative">
                <button 
                  onClick={() => setIsOrderModalOpen(false)}
                  className="absolute top-6 right-6 z-10 w-9 h-9 bg-black/60 hover:bg-black/90 flex items-center justify-center rounded-full text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
                
                <img 
                  src={selectedItem.image} 
                  alt={selectedItem.name} 
                  className="w-full h-80 object-cover" 
                />
                
                <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#251C17] to-transparent" />
              </div>
              
              <div className="p-8">
                <div className="flex justify-between">
                  <div>
                    <div className="text-[#D4AF37] text-xs mb-1 tracking-widest">SIGNATURE DRINK</div>
                    <h3 className="text-4xl font-medium tracking-tighter">{selectedItem.name}</h3>
                  </div>
                  <div className="text-right">
                    <div className="text-4xl font-light text-[#D4AF37]">${selectedItem.price}</div>
                  </div>
                </div>
                
                <p className="mt-6 text-[#C8B9A8] leading-relaxed">
                  {selectedItem.description}
                </p>
                
                {selectedItem.ingredients && (
                  <div className="mt-8">
                    <div className="uppercase text-xs text-white/50 mb-3">INGREDIENTS</div>
                    <div className="flex flex-wrap gap-2">
                      {selectedItem.ingredients.map((ing, idx) => (
                        <span key={idx} className="text-xs px-4 py-2 bg-white/5 rounded-3xl">{ing}</span>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="mt-10 flex items-center justify-between">
                  <div className="flex items-center border border-white/20 rounded-3xl">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-12 h-12 flex items-center justify-center hover:bg-white/10 rounded-l-3xl active:bg-white/5 transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="px-7 font-mono text-lg tabular-nums">{quantity}</div>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-12 h-12 flex items-center justify-center hover:bg-white/10 rounded-r-3xl active:bg-white/5 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.985 }}
                    onClick={handleAddFromModal}
                    className="bg-[#D4AF37] text-[#1C140F] px-16 py-4 rounded-3xl font-medium flex items-center gap-2 text-sm uppercase tracking-[1px]"
                  >
                    ADD {quantity} TO CART
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;

